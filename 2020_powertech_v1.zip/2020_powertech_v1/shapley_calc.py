import numpy as np
import itertools
from math import ceil
import collections

###########################################################

def factorial(any_int):
    if int(any_int) == 0:
        return 1
    else:
        return int(any_int) * factorial(int(any_int) - 1)

#==============================================================================
#   Full Shapley Calculation
#==============================================================================

def shapley(PLAYERS, VALUES):
    
    subcoalitions = list(VALUES)
    
    # create Shapley value dictionary keyed by player
    shapley_dic = {}
    for i in PLAYERS:
        impttn = 0
        for sc in subcoalitions:
            if i not in sc:
                impttn += factorial(len(sc)) * \
                    factorial(len(PLAYERS) -len(sc) -1) * \
                    (VALUES[tuple(sorted(sc + tuple([i])))] - VALUES[sc]) / \
                    factorial(len(PLAYERS))
            impttn = impttn
        shapley_dic[i] = impttn
    
    # create dictionary of Shapley excesses keyed by subcoalition
    sh_exc_dic = {}
    for sc in subcoalitions:
        sh_e = VALUES[sc]
        for i in sc:
            sh_e -= shapley_dic[i]
        sh_exc_dic[sc] = sh_e
    sh_exc_max = max(sh_exc_dic.values())
        
    #########################################################
    # Return Results #
    
    return (shapley_dic, sh_exc_dic, sh_exc_max)

#==============================================================================
#   Shapley Estimation with Sampling
#==============================================================================

def shapley_sampling(PLAYERS, V_DIC, EC_PLAYER, L_SIM, BTR, BTR_CNT, BTR_AVAIL,
                     DT, T, L_GC_P, P_B, P_S, SMPL_TYPE, SMPL_PP, EXP_PERC, \
                     SMPL_INC_SWITCH, SMPL_INC_PP, SMPL_SIG, SMPL_SIMP):
    
    # PLAYERS: player list, V_DIC: value dictionary keyed by coalition, 
    # EC_PLAYER: list of individual player energy costs without cooperation,
    # L_SIM: list of lists, net load prediction by player [kWh],
    # BAT_LIST: list of batteries that are possible options, BTR_CNT: empty,
    # BTR_AVAIL: ES assignment as lists with len(NO_PLAYERS) elements
    # DT: simulation timestep in [min], T: simulation length in [days], 
    # L_GC_P: list of individual net load profiles with coop GC in [kW],
    # P_B, P_S: list of energy buy and sell prices 
    # SMPL_TYPE: whether to use and which sampling method to use for Shapley, 
    # SMPL_PP: average number of samples for each player, EXP_PERC: the 
    # fraction of samples used in the first stage of St-ApproShapley-opt,
    # SMPL_INC_SWITCH: whether to use the multi-step sampling for Shapley,
    # SMPL_INC_PP: the number of samples per step per player,
    # SMPL_SIG: est criterion (standard err of est as % of average payoff),
    # SMPL_SIMP: whether to use the GC cooperation for sampling value calcs
    
    N = len(PLAYERS)
    smpl_sc = []

    v_smpl_sc = {}
    v_smpl_sc[()] = 0
    
    if SMPL_INC_SWITCH == 0:
        iter_tot = 1
    else:
        iter_tot = ceil(SMPL_PP / SMPL_INC_PP)
    smpl_iter = 0
    smpl_sig_prog = ['N/A']
    sh_iter = {}
    
    #########################################################
    # Basic Random Sampling #
    
    if SMPL_TYPE == 1:
        if SMPL_INC_SWITCH == 1:
            smpl_per_p = SMPL_INC_PP
        else:
            smpl_per_p = SMPL_PP
        
        marg_i_sum = {}
        for i in PLAYERS:
            marg_i_sum[i] = 0
        while smpl_iter <= iter_tot-1:
            smpl_iter += 1
            if SMPL_INC_SWITCH == 1:
                print('iteration %d' % smpl_iter)
            sh_iter[smpl_iter] = []
            for i in PLAYERS:
                smpl_pp_ct = 1
                
                while smpl_pp_ct <= smpl_per_p:
                    rand_w_i = list(
                        np.random.choice(PLAYERS, N, replace=False))
                    list_w_i = rand_w_i[:rand_w_i.index(i)+1]
                    list_wo_i = rand_w_i[:rand_w_i.index(i)]
                    p_smpl = tuple(sorted(list_w_i))
                    p_smpl_wo_i = tuple(sorted(list_wo_i))
                    if p_smpl not in smpl_sc:
                        smpl_sc.append(p_smpl)
                        try:
                            v_smpl_sc[p_smpl] = V_DIC[p_smpl]
                        except:
                            v_smpl_sc[p_smpl] = smpl_v_calc(
                                    PLAYERS, EC_PLAYER, p_smpl, DT, T, \
                                    P_B, P_S, BTR, BTR_CNT, BTR_AVAIL, \
                                    L_SIM, L_GC_P, SMPL_SIMP)
                    if p_smpl_wo_i not in smpl_sc:
                        smpl_sc.append(p_smpl_wo_i)
                        try:
                            v_smpl_sc[p_smpl_wo_i] = V_DIC[p_smpl_wo_i]
                        except:
                            v_smpl_sc[p_smpl_wo_i] = smpl_v_calc(
                                    PLAYERS, EC_PLAYER, p_smpl_wo_i, DT, \
                                    T, P_B, P_S, BTR, BTR_CNT, BTR_AVAIL, \
                                    L_SIM, L_GC_P, SMPL_SIMP)
                    marg_v_smpl_i = v_smpl_sc[p_smpl] - v_smpl_sc[p_smpl_wo_i]
                    #print(marg_v_smpl_i)
                    marg_i_sum[i] += marg_v_smpl_i
                    smpl_pp_ct += 1
                    
                sh_iter[smpl_iter].append(
                    marg_i_sum[i] * 1.0 / (smpl_per_p * smpl_iter))
                #print(sh_iter[smpl_iter])
            
            # examine if covergence criterion is met
            if SMPL_INC_SWITCH == 1:
                if smpl_iter > 1:
                    sh_sqrd_err = [(x-y)**2 for x, y in zip(
                        sh_iter[smpl_iter], sh_iter[smpl_iter-1])]
                    sh_err_perc_iter = (sum(sh_sqrd_err) / N) ** 0.5 \
                                            / (v_smpl_sc[tuple(PLAYERS)] / N)
                    smpl_sig_prog.append(sh_err_perc_iter)
                    print('Shapley estimation standard error of estimation'
                          + ' (%%): %.2f %%' % (sh_err_perc_iter * 100))
                    if sh_err_perc_iter <= SMPL_SIG:
                        print('Random sampling took %d iterations.' %smpl_iter)
                        break
            
    
    #########################################################
    # Stratified Random Sampling #
    
    else:
        if SMPL_INC_SWITCH == 1:
            smpl_m = SMPL_INC_PP * N
        else:
            smpl_m = SMPL_PP * N
    
        variance_est = {}
        
        m_exp_il = {}
        m_st_il = {}
        m_il = {}
        m_il_tot = {}
        marg_il_sum = {}
        sum_cuad_il = {}
        for l in PLAYERS:
            for i in PLAYERS:
                m_il_tot[tuple([i,l])] = 0
                marg_il_sum[tuple([i,l])] = 0
                sum_cuad_il[tuple([i,l])] = 0
        sh_il = {}
        smpl_iter = 0
        iter_init = 1
        
        while smpl_iter <= iter_tot-1:
            
            smpl_iter += 1
            m_exp = round(smpl_m / N**2 * EXP_PERC, 0)
            m_split = smpl_m
            sh_iter[smpl_iter] = []
            # for the first iteration, accumulate until m_exp >= 2 so it can be 
            # used for the variance calculation. It is done by combining the
            # samples in the first few iterations  
            if smpl_iter == 1:
                while m_exp < 2:
                    sh_iter[smpl_iter] = [0.] * N
                    print('skipped iteration %d' % smpl_iter)
                    smpl_iter += 1
                    m_exp = round(smpl_m * smpl_iter / N**2 * EXP_PERC, 0)
                    m_split = smpl_m * smpl_iter
                    sh_iter[smpl_iter] = []
                    smpl_sig_prog.append('(skipped)')
                    iter_init += 1
            # for later iterations, accumulate until m_exp >= 1 so it can be 
            # used for the first stage of sampling. It is done by combining 
            # the samples in the next few iterations  
            else:
                smpl_accumulator = 1
                while m_exp < 1:
                    sh_iter[smpl_iter] = sh_iter[smpl_iter-1]
                    print('skipped iteration %d' % smpl_iter)
                    smpl_iter += 1
                    smpl_accumulator += 1
                    m_exp = round(
                        smpl_m * smpl_accumulator / N**2 * EXP_PERC, 0)
                    m_split = smpl_m * smpl_accumulator
                    sh_iter[smpl_iter] = []
                    smpl_sig_prog.append('(skipped)')
            
            if SMPL_INC_SWITCH == 1:
                print('iteration %d' % smpl_iter)
            
        #-----------------------------------------
        # Stage 1: Even Stratified Sampling #
        
            variance_est_sum = 0
            m_st_neg_ct = 0
            
            for l in PLAYERS:
                for i in PLAYERS:
                    smpl_pp_ct = 1
                    p_wo_i = list(range(1, i)) + list(range(i+1, N+1))
                    
                    if SMPL_TYPE == 3 or SMPL_TYPE == 4:
                        p_wo_i_comb = []
                        if m_exp >= factorial(N-1) / (factorial(l-1) \
                                                      * factorial(N-l)):
                            if SMPL_TYPE == 3 or smpl_iter == iter_init:
                                for subset in itertools.combinations(
                                                                p_wo_i, l-1):
                                    p_wo_i_comb.append(subset)
                                #print("%d should equal %d" % (factorial(N-1) \
                                    #/ (factorial(l-1) * factorial(N-l)),
                                    #len(p_wo_i_comb)))
                                for p_smpl_wo_i in p_wo_i_comb:
                                    p_smpl = tuple(
                                        sorted(list(p_smpl_wo_i) + [i]))
                                    if p_smpl not in smpl_sc:
                                        smpl_sc.append(p_smpl)
                                        try:
                                            v_smpl_sc[p_smpl] = V_DIC[p_smpl]
                                        except:
                                            v_smpl_sc[p_smpl] = smpl_v_calc(
                                                    PLAYERS, EC_PLAYER, p_smpl, 
                                                    DT, T, P_B, P_S, BTR, 
                                                    BTR_CNT, BTR_AVAIL, L_SIM, 
                                                    L_GC_P, SMPL_SIMP)
                                    if p_smpl_wo_i not in smpl_sc:
                                        smpl_sc.append(p_smpl_wo_i)
                                        try:
                                            v_smpl_sc[p_smpl_wo_i] = V_DIC[
                                                                p_smpl_wo_i]
                                        except:
                                            v_smpl_sc[
                                                p_smpl_wo_i] = smpl_v_calc(
                                                    PLAYERS, EC_PLAYER, 
                                                    p_smpl_wo_i, DT, T, P_B, 
                                                    P_S, BTR, BTR_CNT, 
                                                    BTR_AVAIL, L_SIM, L_GC_P, 
                                                    SMPL_SIMP)
                                    marg_v_smpl_i = v_smpl_sc[p_smpl] - \
                                                        v_smpl_sc[p_smpl_wo_i]
                                    marg_il_sum[tuple([i,l])] += marg_v_smpl_i
                                
                                m_exp_il[tuple([i,l])] = len(p_wo_i_comb)
                                m_il[tuple([i,l])] = m_exp_il[tuple([i,l])]
                                m_st_il[tuple([i,l])] = 0
                            else:
                                m_exp_il[tuple([i,l])] = 0
                                m_il[tuple([i,l])] = 0
                                m_st_il[tuple([i,l])] = 0
                            m_il_tot[tuple([i,l])] += m_exp_il[tuple([i,l])]
                            m_split -= m_exp_il[tuple([i,l])]
                            #print('m_split = %d' % m_split)
                        else:
                            while smpl_pp_ct <= m_exp:
                                p_smpl_wo_i = tuple(
                                    sorted(np.random.choice(
                                        p_wo_i, l-1, replace=False)))
                                p_smpl = tuple(sorted(list(p_smpl_wo_i) + [i]))
                                if p_smpl not in smpl_sc:
                                    smpl_sc.append(p_smpl)
                                    try:
                                        v_smpl_sc[p_smpl] = V_DIC[p_smpl]
                                    except:
                                        v_smpl_sc[p_smpl] = smpl_v_calc(
                                                PLAYERS, EC_PLAYER, p_smpl, 
                                                DT, T, P_B, P_S, BTR, BTR_CNT, 
                                                BTR_AVAIL, L_SIM, L_GC_P, 
                                                SMPL_SIMP)
                                if p_smpl_wo_i not in smpl_sc:
                                    smpl_sc.append(p_smpl_wo_i)
                                    try:
                                        v_smpl_sc[p_smpl_wo_i] = V_DIC[
                                                                p_smpl_wo_i]
                                    except:
                                        v_smpl_sc[p_smpl_wo_i] = smpl_v_calc(
                                                PLAYERS, EC_PLAYER, 
                                                p_smpl_wo_i, DT, T, P_B, P_S, 
                                                BTR, BTR_CNT, BTR_AVAIL, 
                                                L_SIM, L_GC_P, SMPL_SIMP)
                                marg_v_smpl_i = v_smpl_sc[p_smpl] - \
                                                    v_smpl_sc[p_smpl_wo_i]
                                marg_il_sum[tuple([i,l])] += marg_v_smpl_i
                                sum_cuad_il[tuple([i,l])] += marg_v_smpl_i ** 2
                                smpl_pp_ct += 1
                            m_exp_il[tuple([i,l])] = m_exp
                            m_il_tot[tuple([i,l])] += m_exp_il[tuple([i,l])]
                            variance_est[tuple([i,l])] = (
                                sum_cuad_il[tuple([i,l])] - \
                                    (marg_il_sum[tuple([i,l])])**2 / \
                                    m_il_tot[tuple([i,l])]) / \
                                (m_il_tot[tuple([i,l])] - 1)
                            variance_est_sum += variance_est[tuple([i,l])]
                            
                            # assign temporary m_st. It will be updated later.
                            m_st_il[tuple([i,l])] = m_exp
                            # m_st[tuple([i,l])] to be compared against m_exp
                            m_st_neg_ct += 1
                            
                    elif SMPL_TYPE == 2:
                        p_wo_i_comb = []
                        while smpl_pp_ct <= m_exp:
                            p_smpl_wo_i = tuple(
                                sorted(np.random.choice(p_wo_i, l-1, 
                                                        replace=False)))
                            p_smpl = tuple(sorted(list(p_smpl_wo_i) + [i]))
                            if p_smpl not in smpl_sc:
                                smpl_sc.append(p_smpl)
                                try:
                                    v_smpl_sc[p_smpl] = V_DIC[p_smpl]
                                except:
                                    v_smpl_sc[p_smpl] = smpl_v_calc(
                                            PLAYERS, EC_PLAYER, p_smpl, DT, T,
                                            P_B, P_S, BTR, BTR_CNT, BTR_AVAIL,
                                            L_SIM, L_GC_P, SMPL_SIMP)
                            if p_smpl_wo_i not in smpl_sc:
                                smpl_sc.append(p_smpl_wo_i)
                                try:
                                    v_smpl_sc[p_smpl_wo_i] = V_DIC[p_smpl_wo_i]
                                except:
                                    v_smpl_sc[p_smpl_wo_i] = smpl_v_calc(
                                            PLAYERS, EC_PLAYER, p_smpl_wo_i, 
                                            DT, T, P_B, P_S, BTR, BTR_CNT, 
                                            BTR_AVAIL, L_SIM, L_GC_P, 
                                            SMPL_SIMP)
                            marg_v_smpl_i = v_smpl_sc[p_smpl] - \
                                                    v_smpl_sc[p_smpl_wo_i]
                            marg_il_sum[tuple([i,l])] += marg_v_smpl_i
                            sum_cuad_il[tuple([i,l])] += marg_v_smpl_i ** 2
                            smpl_pp_ct += 1
                        m_exp_il[tuple([i,l])] = m_exp
                        m_il_tot[tuple([i,l])] += m_exp_il[tuple([i,l])]
                        variance_est[tuple([i,l])] = (
                            sum_cuad_il[tuple([i,l])] - \
                                (marg_il_sum[tuple([i,l])])**2 / \
                                    m_il_tot[tuple([i,l])]) / \
                            (m_il_tot[tuple([i,l])] - 1)
                        variance_est_sum += variance_est[tuple([i,l])]
                        # assign temporary m_st, which will be updated later
                        m_st_il[tuple([i,l])] = m_exp
                        # m_st[tuple([i,l])] needs to be compared against m_exp
                        m_st_neg_ct += 1
        
            #-----------------------------------------
            # Based on Stage 1 Results Calculate Stage 2 Sample Distribution #
            
            m_il_temp = {}
            variance_est_sum_temp_1 = variance_est_sum
            while m_st_neg_ct > 0:
                m_st_neg_ct = 0
                m_split_temp = m_split
                variance_est_sum_temp_2 = variance_est_sum_temp_1
                for l in PLAYERS:
                    for i in PLAYERS:
                        if m_st_il[tuple([i,l])] > 0:
                            m_il_temp[tuple([i,l])] = round(
                                m_split_temp * variance_est[tuple([i,l])] / \
                                    variance_est_sum_temp_2, 0)
                            if m_il_temp[tuple([i,l])] <= m_exp:
                                m_st_il[tuple([i,l])] = 0
                                m_il[tuple([i,l])] = m_exp
                                m_split -= m_exp
                                variance_est_sum_temp_1 -= variance_est[
                                                                tuple([i,l])]
                                m_st_neg_ct += 1
                            else:
                                m_il[tuple([i,l])] = m_il_temp[tuple([i,l])]
                                m_st_il[tuple([i,l])] = m_il[tuple([i,l])] - \
                                                                        m_exp
            for l in PLAYERS:
                for i in PLAYERS:
                    m_il_tot[tuple([i,l])] += m_st_il[tuple([i,l])]
                                
            print("m_exp_il sum = %f" % sum(m_exp_il.values()))
            print("m_st_il sum = %f" % sum(m_st_il.values()))
            print("m_il sum = %f" % sum(m_il.values()))
            print("m_il_tot sum = %f" % sum(m_il_tot.values()))
            
            #-----------------------------------------
            # Stage 2: Optimal Stratified Sampling #
            
            for l in PLAYERS:
                for i in PLAYERS:
                    smpl_pp_ct_st2 = 1
                    p_wo_i = list(range(1, i)) + list(range(i+1, N+1))
                                
                    while smpl_pp_ct_st2 <= m_st_il[tuple([i,l])]:
                        p_smpl_wo_i = tuple(sorted(
                                np.random.choice(p_wo_i, l-1, replace=False)))
                        p_smpl = tuple(sorted(list(p_smpl_wo_i) + [i]))
                        if p_smpl not in smpl_sc:
                            smpl_sc.append(p_smpl)
                            try:
                                v_smpl_sc[p_smpl] = V_DIC[p_smpl]
                            except:
                                v_smpl_sc[p_smpl] = smpl_v_calc(
                                        PLAYERS, EC_PLAYER, p_smpl, DT, T, \
                                        P_B, P_S, BTR, BTR_CNT, BTR_AVAIL, \
                                        L_SIM, L_GC_P, SMPL_SIMP)
                        if p_smpl_wo_i not in smpl_sc:
                            smpl_sc.append(p_smpl_wo_i)
                            try:
                                v_smpl_sc[p_smpl_wo_i] = V_DIC[p_smpl_wo_i]
                            except:
                                v_smpl_sc[p_smpl_wo_i] = smpl_v_calc(
                                        PLAYERS, EC_PLAYER, p_smpl_wo_i, DT, 
                                        T, P_B, P_S, BTR, BTR_CNT, BTR_AVAIL, 
                                        L_SIM, L_GC_P, SMPL_SIMP)
                        marg_v_smpl_i = v_smpl_sc[p_smpl] - \
                                                v_smpl_sc[p_smpl_wo_i]
                        marg_il_sum[tuple([i,l])] += marg_v_smpl_i
                        sum_cuad_il[tuple([i,l])] += marg_v_smpl_i ** 2
                        smpl_pp_ct_st2 += 1
                    sh_il[tuple([i,l])] = marg_il_sum[tuple([i,l])] / \
                                                    m_il_tot[tuple([i,l])]
            
            #-----------------------------------------
            # Estimate Shapley by Averaging the Sampled Results #
            for i in PLAYERS:
                sh_opt = 0
                for l in PLAYERS:
                    sh_opt += sh_il[tuple([i,l])] / N
                sh_iter[smpl_iter].append(sh_opt)
                
            #-----------------------------------------
            # Examine if covergence criterion is met #
            
            if SMPL_INC_SWITCH == 1:
                if smpl_iter > iter_init:
                    sh_sqrd_err = [(x-y)**2 for x, y in zip(
                        sh_iter[smpl_iter], sh_iter[smpl_iter-1])]
                    
                    sh_err_perc_iter = (sum(sh_sqrd_err) / N) ** 0.5 \
                                            / (v_smpl_sc[tuple(PLAYERS)] / N)
                    smpl_sig_prog.append(sh_err_perc_iter)
                    print('Shapley estimation standard error of estimation'
                          + ' (%%): %.2f %%' % (sh_err_perc_iter * 100))
                    if sh_err_perc_iter <= SMPL_SIG:
                        print('Stratified Random sampling took %d iterations.' 
                              % smpl_iter)
                        break
    
    #########################################################
    # Final Shapley Estimation #
    
    sh_smpl = {}
    for i in PLAYERS:
        sh_smpl[i] = sh_iter[smpl_iter][i-1]
    
    #########################################################
    # Calculate the excesses of all sampled coalitions #
    
    sh_exc_dic = {}
    smpl_sc_sorted = sorted(smpl_sc)
    smpl_sc_sorted.sort(key=lambda t: len(t))
    for sc in smpl_sc_sorted:
        sh_e = v_smpl_sc[sc]
        for i in sc:
            sh_e -= sh_smpl[i]
        sh_exc_dic[sc] = sh_e
    sh_exc_max = max(sh_exc_dic.values())
    
    #########################################################
    # Return Results #
    
    # remove empty coalitions from the sampled coalition list and value dic
    smpl_sc_sorted.remove(())
    del v_smpl_sc[()]
    # order the value dictionary based on keys
    v_smpl_sc = collections.OrderedDict(sorted(v_smpl_sc.items()))
    
    return (smpl_sc_sorted, v_smpl_sc, sh_smpl, sh_exc_dic, sh_exc_max,
            sh_iter, smpl_sig_prog)
        